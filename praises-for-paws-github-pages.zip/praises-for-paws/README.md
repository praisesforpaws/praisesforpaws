# Praises for Paws — GitHub Pages site

## Included pages
- `index.html`: home, image carousel, mission, three goals, editable impact figures, ways to help
- `about.html`: organization mission and sample team profiles
- `donate.html`: donation page and demo form
- `programs.html`: fundraising, adoption campaigns, advocacy
- `volunteer.html`: volunteer information and demo interest form
- `events.html`: event cards with click-to-open image galleries
- `stories.html`: pet success story cards
- `contact.html`: contact details and demo message form

## Publish with GitHub Pages
1. Create a repository. For a user site, name it `YOUR-USERNAME.github.io`.
2. Upload the contents of this folder to the repository root. Keep `index.html` at the root.
3. Go to repository **Settings → Pages**.
4. Under build/deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. Once deployment finishes, open the URL GitHub Pages provides.

## Customize before launch
- Replace sample team names, event dates/locations, pet stories, email address, and `#` social links.
- Edit the four impact figures directly in the impact section of `index.html`.
- The photos currently load from Unsplash URLs; replace them with approved photos if desired.
- Donation, volunteer, and contact forms are demos only: they do not send email, store data, or process payments. Connect a form backend/service before launch. For real donations, use a reputable payment provider and confirm your organization's legal/tax status. Never collect card details in plain HTML.
- Keep image permission and privacy/consent in mind when sharing pet or volunteer photos.
